#ifndef DBFILE_H
#define DBFILE_H

#include "TwoWayList.h"
#include "Record.h"
#include "Schema.h"
#include "File.h"
#include "Comparison.h"
#include "ComparisonEngine.h"
#include "BigQ.h"
#include <iostream>
typedef enum {heap, sorted, tree} fType;

struct SortInfo
{	
	OrderMaker *myOrder;
	int runlength;
};

// stub DBFile header..replace it with your own DBFile.h 

class DBFile_Generic {
	protected :
		File *file_obj;
		Page *currentwritepage;
		Page *currentreadpage;
		off_t NumOfPages;

		bool write_to_disk;
		bool is_open;
		int read_pointer;


public:
	DBFile_Generic ();
	//~DBFile_Generic ();

	char name[200];

	virtual int Create (char *fpath)=0;
	virtual int Open (char *fpath)=0;
	virtual int Close ()=0;

	virtual void Load (Schema &myschema, char *loadpath)=0;

	virtual void MoveFirst ()=0;
	virtual void Add (Record &addme)=0;
	virtual int GetNext (Record &fetchme)=0;
	virtual int GetNext (Record &fetchme, CNF &cnf, Record &literal)=0;

};

class DBFile_Heap : public DBFile_Generic{
private:

public:
	DBFile_Heap ();

	int Create (char *fpath);
	int Open (char *fpath);
	int Close ();

	void Load (Schema &myschema, char *loadpath);

	void MoveFirst ();
	void Add (Record &addme);
	int GetNext (Record &fetchme);
	int GetNext (Record &fetchme, CNF &cnf, Record &literal);

};

class DBFile_Sorted : public DBFile_Generic {

		int numofrecs;
		int runLength;
		BigQ* bigQ;
		Pipe* inputpipe;
		Pipe* outputpipe;
		OrderMaker *DBfile_order;
		int runlength;
		bool write_mode;
		File newFile;

		int searchPhase;
		OrderMaker query_order;
		OrderMaker literal_order;
		int BinarySearch(Record &literal, Record &fetchMe);

		void Merge(void);
		void writeInNewFile (Record &addMe);
		int getLengthOfNewFile();

public:


	DBFile_Sorted (OrderMaker *ordermaker,int runs);

	int Create (char *fpath);
	int Open (char *fpath);
	int Close ();

	void Load (Schema &myschema, char *loadpath);

	void MoveFirst ();
	void Add (Record &addme);
	int GetNext (Record &fetchme);
	int GetNext (Record &fetchme, CNF &cnf, Record &literal);

};

class DBFile {



public:
	DBFile_Generic  *myInternalVar;

	DBFile ();
	//~DBFile ();

	int Create (char *fpath, fType file_type, void *startup);
	int Open (char *fpath);

	int Close ();

	void Load (Schema &myschema, char *loadpath);

	void MoveFirst ();
	void Add (Record &addme);
	int GetNext (Record &fetchme);
	int GetNext (Record &fetchme, CNF &cnf, Record &literal);

};

#endif
