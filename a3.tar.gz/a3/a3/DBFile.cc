#include "TwoWayList.h"
#include "Record.h"
#include "Schema.h"
#include "File.h"
#include "Comparison.h"
#include "ComparisonEngine.h"
#include "DBFile.h"
#include "Defs.h"
#include "fstream"
#include <string.h>

using namespace std;


// stub file .. replace it with your own DBFile.cc

DBFile::DBFile () {	
}
/*
DBFile::~DBFile () {
	delete myInternalVar;
}*/

int DBFile::Create (char *f_path, fType f_type, void *startup) {
		
	char fname[100];
	sprintf(fname,"%s.meta",f_path);
	FILE *metaFile=fopen(fname,"w");

	if(!metaFile){
	cout<<"Cant access the  meta data file"<<endl;
	}

		switch(f_type){
			case heap:{
			fwrite("h",1,1,metaFile);

			myInternalVar = new DBFile_Heap();
			strcpy(myInternalVar->name, f_path);
			myInternalVar->Create(f_path);

			
			break;

			}

			case sorted:

			{
	
			fwrite("s",1,1,metaFile);

			SortInfo s;
			s.myOrder=((SortInfo *) startup)->myOrder;
			s.runlength=((SortInfo *) startup)->runlength;

			int sizeofmyorder= sizeof(*s.myOrder);

			fwrite((void *)&sizeofmyorder,sizeof(int),1,metaFile);
			fwrite((void *)s.myOrder,sizeofmyorder,1,metaFile);
			fwrite((void *)&s.runlength,sizeof(int),1,metaFile);


			myInternalVar = new DBFile_Sorted(s.myOrder,s.runlength);
			myInternalVar -> Create(f_path);
			strcpy(myInternalVar->name, f_path);

			}
			

			break;

			case tree:
			break;

			default:
			cout << "Incorrect File type"<<endl;
			return 0;
		}

		fclose(metaFile);


}

int DBFile::Open (char *f_path) {


	char fname[100];
	sprintf(fname,"%s.meta",f_path);
	FILE *metaFile=fopen(fname,"r");
	if(!metaFile){
	cout<<"Cant open the meta data file"<<endl;
	}


	char c;
	fread(&c,1,1,metaFile);

	switch(c){

	case 'h':{
		myInternalVar = new DBFile_Heap();
		myInternalVar ->Open(f_path);
		strcpy(myInternalVar->name, f_path);

		break ;

	}


	case 's':{
		int sizeofmyorder;

		fread(&sizeofmyorder,sizeof(int),1,metaFile);

			OrderMaker *myorder=new OrderMaker;
			fread(myorder,sizeofmyorder,1,metaFile);
		
			int runlen;
			fread(&runlen,sizeof(int),1,metaFile);
			
			myInternalVar = new DBFile_Sorted(myorder,runlen);
			myInternalVar ->Open(f_path);
			strcpy(myInternalVar->name, f_path);

		break;
	}

	default :{
		cout<<"Wrong data in meta data file"<<endl;
		return 0;
	}

	}
	fclose(metaFile);


}

void DBFile::Load (Schema &f_schema, char *loadpath) {
	myInternalVar ->Load(f_schema, loadpath);
}



void DBFile::MoveFirst () {
	myInternalVar ->MoveFirst();
}

int DBFile::Close () {
	myInternalVar ->Close();
	delete myInternalVar;
}

void DBFile::Add (Record &rec) {
	myInternalVar ->Add(rec);
}

int DBFile::GetNext (Record &fetchme) {
	myInternalVar ->GetNext(fetchme);
}

int DBFile::GetNext (Record &fetchme, CNF &cnf, Record &literal) {
	myInternalVar ->GetNext(fetchme,cnf,literal);
}



DBFile_Generic::DBFile_Generic () {

	file_obj= new File;
	currentwritepage =new Page;		
	currentreadpage =NULL;		
	NumOfPages=0;				
	write_to_disk=false;
	read_pointer=0;				
	is_open=false;
}

/*
DBFile_Generic::~DBFile_Generic () {

	delete file_obj;
	delete currentwritepage;
	if(currentreadpage){
		delete currentreadpage;
	}

}
*/


DBFile_Sorted::DBFile_Sorted (OrderMaker *ordermaker,int runs) {

	DBfile_order=ordermaker;
	runlength=runs;
	write_mode=false;
	numofrecs=0;

}

int DBFile_Sorted::Create (char *f_path) {
				file_obj->Open(0,f_path);
				is_open=true;
				write_mode=false;
				bigQ = NULL;
				inputpipe = NULL;
				outputpipe = NULL;
				return 1;
}

int DBFile_Sorted::Open (char *f_path) {

				file_obj->Open(1,f_path);
				is_open=true;
				return 1;
				write_mode=false;
				bigQ = NULL;
				inputpipe = NULL;
				outputpipe = NULL;
}

void DBFile_Sorted::Load (Schema &f_schema, char *loadpath) {

	if(!is_open){
		cout<<"Couldn't load the file ";
		return;
	}

	if(!write_mode){
		delete currentreadpage;
		read_pointer=0;
		write_mode=true;


		inputpipe=new Pipe(100);
		outputpipe=new Pipe(100);

		bigQ= new BigQ(*inputpipe, *outputpipe, *DBfile_order, runlength);
	}

	FILE *tbl_file=fopen(loadpath,"r");

	if(!tbl_file){

		cout<<"Couldn't open the sorted DBFile"<<endl;
		return;
	}

	Record *temp=new Record;

	while(temp->SuckNextRecord(&f_schema,tbl_file))
		inputpipe->Insert(temp);



	fclose(tbl_file);


}

void DBFile_Sorted::MoveFirst () {
	
	if (write_mode)
	{
		write_mode=false;
		Merge();
		delete bigQ;
		delete inputpipe;
		delete outputpipe;
	}

	read_pointer = 0;
	delete currentreadpage;
	searchPhase = 0;
	currentreadpage = new Page;
	if (file_obj->GetLength() != 0){
		file_obj->GetPage (currentreadpage, read_pointer);

	}
}

int DBFile_Sorted::Close () {
	
	if(is_open){
		if(write_mode)
		{
			write_mode=false;
			Merge();
			delete bigQ;
			delete inputpipe;
			delete outputpipe;
		}
		file_obj->Close ();
		is_open = false;
	}

	
	delete file_obj;
	delete currentwritepage;
	if(currentreadpage){
		delete currentreadpage;
	}

		return 1;
}

void DBFile_Sorted::Add (Record &rec) {
		if(!DBfile_order){
			cout<<"Order Maker value is NULL"<<endl;
		}

		if(!write_mode){
			delete currentreadpage;
			read_pointer=0;
			write_mode=true;

			inputpipe=new Pipe(100);
			outputpipe=new Pipe(100);


			bigQ= new BigQ(*inputpipe, *outputpipe, *DBfile_order, runlength);

		}
	//	else{
		inputpipe->Insert(&rec);
		//}
}



void DBFile_Sorted :: Merge(void)
{


	if(!inputpipe){
		cout<<"Value of the input pipe is null "<<endl;

	}
	if(!outputpipe){
			cout<<" Value of the outputput pipe is null"<<endl;

	}

	char *newfilename = new char[50];
	strcpy(newfilename, "newfile.tmp");
	newFile.Open (0, newfilename);

	ComparisonEngine comp;

	Record pipeRec, fileRec;


	inputpipe->ShutDown();


	MoveFirst();

	bool file_exhausted = false;
	bool pipe_exhausted = false;


	if(!outputpipe->Remove(&pipeRec))
	{
		pipe_exhausted = true;
	}

	if (!GetNext(fileRec))
	{
		file_exhausted = true;
	}

	while( !pipe_exhausted && !file_exhausted )
	{
		if (comp.Compare(&pipeRec, &fileRec, DBfile_order) < 0)
		{
			writeInNewFile(pipeRec);
			if( !outputpipe->Remove(&pipeRec) )
			{
				pipe_exhausted = true;
			}
		}
		else
		{
			writeInNewFile(fileRec);
			if( !GetNext(fileRec) )
			{
				file_exhausted = true;
			}
		}
	}


	if( !pipe_exhausted )
	{
		writeInNewFile(pipeRec);
		while(outputpipe->Remove(&pipeRec))
		{
			writeInNewFile(pipeRec);
		}
	}

	if( !file_exhausted )
	{
		writeInNewFile(fileRec);
		while(GetNext(fileRec))
		{
			writeInNewFile(fileRec);
		}
	}

	newFile.AddPage (currentwritepage, getLengthOfNewFile());
	currentwritepage->EmptyItOut();

	newFile.Close();
	file_obj->Close();

	remove(name);
	rename(newfilename, name);

	delete newfilename;

}

void DBFile_Sorted :: writeInNewFile (Record &addMe)
{
	if( currentwritepage -> Append (&addMe) == 0)
	{
		newFile.AddPage (currentwritepage, getLengthOfNewFile());
		currentwritepage->EmptyItOut();
		currentwritepage->Append(&addMe);
	}
}


int DBFile_Sorted:: getLengthOfNewFile()
{
        if(newFile.GetLength() == 0)
        {
        	return 0;
        }
        else
        {
         return newFile.GetLength() - 1;
        }
}


int DBFile_Sorted::GetNext (Record &fetchme) {

	if(write_mode){
		write_mode=false;
		Merge();
		delete bigQ;
		delete inputpipe;
		delete outputpipe;
	}

	if(currentreadpage == NULL)
	{
		currentreadpage = new Page;
		file_obj->GetPage (currentreadpage, read_pointer);
	}

		int val=currentreadpage->GetFirst(&fetchme);
		
		if(val==0)
		{
			read_pointer++;
			if(read_pointer<file_obj->GetLength()-1){
			currentreadpage->EmptyItOut();
			file_obj->GetPage(currentreadpage,read_pointer);
			val=currentreadpage->GetFirst(&fetchme);
			if(val==0)
			return 0;
			}
			else return 0;
			return 1;
		}
		else return 1;
}


int DBFile_Sorted :: GetNext(Record &fetchMe, CNF &applyMe, Record &literal)
{
	if(write_mode){
			write_mode=false;
			Merge();
			delete bigQ;
			delete inputpipe;
			delete outputpipe;
	}

	ComparisonEngine comp;
	int val;

	switch(searchPhase)
	{
		case 0:
		{
			val=applyMe.GetSortOrders(*DBfile_order, query_order, literal_order);
		


			if(!val)
			{
					searchPhase = 2;
				    bool getnext=true;

				    while(getnext){

					int flag=this->GetNext(fetchMe);
					if(flag==0)
					return 0;

					if(comp.Compare(&fetchMe,&literal,&applyMe))
						getnext=false;

					}
					return 1;
			}
			else
			{
				if(BinarySearch(literal, fetchMe)==0)
				{
					searchPhase = 3;
					return 0;
				}
				else
				{
					searchPhase = 1;
					do
					{
						if( comp.Compare(&fetchMe, &literal, &applyMe) !=0 )
						{
							return 1;
						}
						if(comp.Compare(&fetchMe, &query_order, &literal, &literal_order) > 0 )
						{
							searchPhase = 3;
							return 0;
						}
					}while(GetNext(fetchMe)!=0);
					return 0;
				}
			}
			break;
		}
		case 1:
		{
			while(GetNext(fetchMe)!=0)
			{
				if( comp.Compare(&fetchMe, &literal, &applyMe) !=0 )
					return 1;
				if(comp.Compare(&fetchMe, &query_order, &literal, &literal_order) > 0 )
				{
					searchPhase = 3;
					return 0;
				}
			}
			return 0;
			break;
		}
		case 2:
		{
			while(GetNext(fetchMe)!=0)
			{
				if( comp.Compare(&fetchMe, &literal, &applyMe) !=0 )
				return 1;
			}

			return 0;
			break;
		}
		case 3:
		{
			return 0;
			break;
		}
	}
	return 0;
}


int DBFile_Sorted :: BinarySearch(Record &literal, Record &fetchMe)
{

	ComparisonEngine comp;
	int startpage = 0;
	int endpage = file_obj->GetLength()-2;
	int temp;
	while(endpage>startpage+1)
	{
		int mid = (startpage + endpage) / 2;

		if(currentreadpage != NULL)
		{
			currentreadpage->EmptyItOut();
		}
		else
		{
			currentreadpage = new Page;
		}
		file_obj->GetPage(currentreadpage, mid);
		currentreadpage->GetFirst(&fetchMe);

		int temp = comp.Compare(&fetchMe, &query_order, &literal, &literal_order);

		if(temp>=0)
		{
			endpage = mid;
		}
		else
		{
			startpage = mid;
		}
	}

	read_pointer = startpage;
	currentreadpage->EmptyItOut();
	
	if(file_obj->GetLength() > read_pointer)
	{
		file_obj->GetPage(currentreadpage, read_pointer);
	}
	if( GetNext(fetchMe) ==0)
	{
		return 0;
	}

	int returned_val;

	while(returned_val = comp.Compare(&fetchMe, &query_order, &literal, &literal_order) )
	{
		if(returned_val > 0)
		{
			return 0;
		}
		if( GetNext(fetchMe) ==0)
		{
			return 0;
		}
	}

	return 1;


}





DBFile_Heap::DBFile_Heap () {
}

int DBFile_Heap::Create (char *f_path) {

		file_obj->Open(0,f_path);
		is_open=true;
		return 1;

}

void DBFile_Heap::Load (Schema &f_schema, char *loadpath) {

	if(!is_open)
	{
		cout << "Error in opening DBFile\n";
		return;
	}

	FILE *text_file;
	text_file=fopen(loadpath,"r");

	if(text_file==NULL)		
	{cout<<"Cant open DBFile  "<<endl; return;}

	Record record;
	while(record.SuckNextRecord(&f_schema,text_file)){


		if(!currentwritepage->Append(&record))
		{
			file_obj->AddPage(currentwritepage,NumOfPages);
			currentwritepage->EmptyItOut();
			NumOfPages++;
			currentwritepage->Append(&record);
		}

	}

	fclose(text_file);
	write_to_disk=true;
}

int DBFile_Heap::Open (char *f_path) {

	file_obj->Open(1,f_path);
	is_open=true;

	return 1;

}

void DBFile_Heap::MoveFirst () {
	if(write_to_disk)
	{
	file_obj->AddPage(currentwritepage,NumOfPages);
	currentwritepage->EmptyItOut();
	write_to_disk=false;

	}
	read_pointer=0;
	delete currentreadpage;
	currentreadpage=new Page;

	file_obj->GetPage(currentreadpage,read_pointer);


}

int DBFile_Heap::Close () {
	if(write_to_disk)
	{
	file_obj->AddPage(currentwritepage,NumOfPages);
	currentwritepage->EmptyItOut();
	write_to_disk=false;
	}
	file_obj->Close();

}

void DBFile_Heap::Add (Record &rec) {


	if(!write_to_disk&&file_obj->GetLength()>0){

		NumOfPages=file_obj->GetLength()-2;
		file_obj->GetPage(currentwritepage,NumOfPages);

	}

	if(currentwritepage->Append(&rec)==0)
	{

		file_obj->AddPage(currentwritepage,NumOfPages);
		currentwritepage->EmptyItOut();
		NumOfPages++;
		currentwritepage->Append(&rec);

	}

	write_to_disk=true;

}

int DBFile_Heap::GetNext (Record &fetchme) {

	if(write_to_disk){				//if current page has not been written to disk. write  it.

	file_obj->AddPage(currentwritepage,NumOfPages);
	currentwritepage->EmptyItOut();
	write_to_disk=false;

	}

	int val=currentreadpage->GetFirst(&fetchme);
	if(val==0)
	{
		read_pointer++;
		if(read_pointer<file_obj->GetLength()-1){
		currentreadpage->EmptyItOut();
		file_obj->GetPage(currentreadpage,read_pointer);
		val=currentreadpage->GetFirst(&fetchme);
		if(val==0)
		return 0;
		}
		else return 0;
		return 1;
	}
	else return 1;




}

int DBFile_Heap::GetNext (Record &fetchme, CNF &cnf, Record &literal) {

	ComparisonEngine match;

	bool getnext=true;

	while(getnext){

	int flag=this->GetNext(fetchme);
	if(flag==0)
	return 0;

	if(match.Compare(&fetchme,&literal,&cnf))
		getnext=false;

	}

	return 1;

}
