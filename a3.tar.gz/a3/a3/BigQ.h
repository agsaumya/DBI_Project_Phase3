#ifndef BIGQ_H
#define BIGQ_H
#include <pthread.h>
#include <iostream>
#include "Pipe.h"
#include "File.h"
#include "Record.h"
#include "Comparison.h"
#include <vector>
#include <algorithm>
#include <queue>
#include <stdlib.h>

using namespace std;


class BigQ {

private:
        Pipe *inPipe, *outPipe;
        pthread_t worker_thread;
        OrderMaker *sortOrder;
        int runLength;
        int totalPages;
        int numOfRuns;
        File myFile;
        vector<int> pagesInEachRun;
        vector<int> pagesIndexOfEachRun;
       

public:

    BigQ (Pipe &in, Pipe &out, OrderMaker &sortorder, int runlen);

    void phase1();
    void phase2();
    void write (vector<Record*> recordVector);

    ~BigQ ();
};

#endif




