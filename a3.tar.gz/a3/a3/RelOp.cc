#include "RelOp.h"




/*SelectFile Functions*/

SelectFile :: SelectFile()
{

}

void * sf_routine(void *ob_param)
{
	SelectFile *sf_ob = (SelectFile*) ob_param;
	sf_ob->Worker();
	pthread_exit(NULL);
	
}

void SelectFile::Run (DBFile &inFile, Pipe &outPipe, CNF &selOp, Record &literal) 
{
	
	this->inFile = &inFile;
	this->outPipe = &outPipe;
	this->selOp = &selOp;
	this->literal = &literal;

	pthread_create(&thread,NULL,(sf_routine),(void*)this);	

}


void SelectFile :: Worker()
{
	Record *fetchMe = new Record();
	
	inFile->MoveFirst();
	
	while (inFile->GetNext(*fetchMe, *selOp, *literal)) //DBFile Function: int GetNext (Record &fetchme, CNF &cnf, Record &literal);
	{
		outPipe->Insert(fetchMe);
			fetchMe = new Record();
	}

	delete fetchMe;
	outPipe->ShutDown();
}

void SelectFile::WaitUntilDone () 
{
	pthread_join (thread, NULL);
}


void SelectFile::Use_n_Pages (int n) 
{
	runlen = n;
}




/*SelectPipe Functions*/

SelectPipe :: SelectPipe()
{

}

void * sp_routine(void *ob_param)
{
	SelectPipe *sp_ob = (SelectPipe*) ob_param;
	sp_ob->Worker();
	pthread_exit(NULL);
	
}

void SelectPipe::Run (Pipe &inPipe, Pipe &outPipe, CNF &selOp, Record &literal)
 
{
	
	this->inPipe = &inPipe;
	this->outPipe = &outPipe;
	this->selOp = &selOp;
	this->literal = &literal;

	pthread_create(&thread,NULL,(sp_routine),(void*)this);	

}


void SelectPipe:: Worker() 
{
	Record compareWithMe;
	ComparisonEngine comp;
	
	while (inPipe->Remove(&compareWithMe)) 
	{
		
		if(comp.Compare(&compareWithMe, literal, selOp)) //ComparisonEngine Function: int Compare(Record *left, Record *literal, CNF *myComparison);
			outPipe->Insert(&compareWithMe);
	}


	outPipe->ShutDown();
}

void SelectPipe::WaitUntilDone () 
{
	pthread_join (thread, NULL);
}


void SelectPipe::Use_n_Pages (int n) 
{
	runlen = n;
}



/*Sum Functions*/

Sum :: Sum()
{

}

void * sum_routine(void *ob_param)
{
	Sum *sum_ob = (Sum*) ob_param;
	sum_ob->Worker();
	pthread_exit(NULL);
				
}

void Sum:: Run (Pipe &inPipe, Pipe &outPipe, Function &computeMe)
{
	
	this->inPipe = &inPipe;
	this->outPipe = &outPipe;
	this->computeMe = &computeMe;

	pthread_create(&thread,NULL,(sum_routine),(void*)this);	

}


void Sum::Worker() 
{
	Record sumMe;
	Type recType;
	int intRes, intSum = 0;
	double doubleRes, doubleSum = 0;

	if (inPipe->Remove(&sumMe)) 
	{
		recType = computeMe->Apply(sumMe, intRes, doubleRes); // Function Class Method: Type Apply (Record &toMe, int &intResult, double &doubleResult);
		intSum += intRes;
		doubleSum += doubleRes;
	}
	else
	{
		outPipe->ShutDown();
		return;
	}
	
	while (inPipe->Remove(&sumMe)) 
	{
		recType = computeMe->Apply(sumMe, intRes, doubleRes); // Function Class Method: Type Apply (Record &toMe, int &intResult, double &doubleResult);
		intSum += intRes;
		doubleSum += doubleRes;
	}

	

	Record finalSumRec;
	Attribute outRecAtt;
	
	switch(recType)
	{
	
		case Int:
		{

			char *intArray = new char[sizeof(int)*20]; /////////////////// Adjust
			sprintf(intArray, "%d|", intSum);
				
			outRecAtt = {"Integer", Int}; 
			Schema outRecSchema("intSumSchema", 1, &outRecAtt); // Schema Class Constructor: Schema (char *fName, int num_atts, Attribute *atts)
		
			if(!(finalSumRec.ComposeRecord(&outRecSchema,intArray))) // Record Class Function: int ComposeRecord (Schema *mySchema, const char *src)
			{
				cout<<"Integer Record could not be composed."<<endl;
			}
		
			break;
		}
	
		case Double:
		{
			char *doubleArray = new char[sizeof(double)*20]; /////////////////// Adjust
			sprintf(doubleArray, "%f|", doubleSum);
		
			outRecAtt = {"Double", Double}; 
			Schema outRecSchema("doubleSumSchema", 1, &outRecAtt); // Schema Class Constructor: Schema (char *fName, int num_atts, Attribute *atts)
		
			if(!(finalSumRec.ComposeRecord(&outRecSchema,doubleArray))) // Record Class Function: int ComposeRecord (Schema *mySchema, const char *src)
			{
				cout<<"Double Record could not be composed."<<endl;
			}
	
			break;
		}
		
		default:
			cout<<"Invalid Record Type"<<endl;
	}

	outPipe->Insert(&finalSumRec);
	outPipe->ShutDown();
		
}

void Sum::WaitUntilDone () 
{
	pthread_join (thread, NULL);
}


void Sum::Use_n_Pages (int n) 
{
	runlen = n;
}


/*GroupBy Functions*/

GroupBy :: GroupBy()
{

}

void * gb_routine(void *ob_param)
{
	GroupBy *gb_ob = (GroupBy*) ob_param;
	gb_ob->Worker();
	pthread_exit(NULL);
		
}


void GroupBy::Run (Pipe &inPipe, Pipe &outPipe, OrderMaker &groupAtts, Function &computeMe)
 
{
	
	this->inPipe = &inPipe;
	this->outPipe = &outPipe;
	this->groupAtts = &groupAtts;
	this->computeMe = &computeMe;

	pthread_create(&thread,NULL,(gb_routine),(void*)this);	

}


void GroupBy:: Worker() 
{
	tempPipe = new Pipe(100);
	bigQ = new BigQ(*inPipe,*tempPipe,*groupAtts,runlen); // Now tempPipe contains all the records sorted based on the attributes in the OrderMaker.

	Record currentRecord, nextRecord, newRecord, tempRecord;
	ComparisonEngine comp;
	double finalSum = 0, doublePartialResult=0;
	int intPartialResult=0, numOfAttsInOutput, numOfAttsInOrderMaker;
	int *attsInOrderMaker;
	Type recType;
	
	attsInOrderMaker = groupAtts->whichAtts; 
	numOfAttsInOrderMaker = groupAtts->numAtts; 
	numOfAttsInOutput = numOfAttsInOrderMaker + 1; // The first attribute of every record will contain the additional sum value.

	int *attsInOutput = new int[numOfAttsInOutput];
	attsInOutput[0] = 0; // The position of the Sum is set to zero, since it was not present in the original records.

	for(int i=1; i<numOfAttsInOutput; i++)
		attsInOutput[i] = attsInOrderMaker[i-1]; // Saving the original position of the required attributes (in the initial record) relative to the new one. 


	Attribute sumAttr;
	sumAttr = {"Sum", Double}; // New sum attribute
	Schema sumSchema ("sumSchema", 1, &sumAttr); // Schema for the newly created Sum attribute

	if(tempPipe->Remove(&currentRecord))
	{ 
		recType=computeMe->Apply(currentRecord, intPartialResult, doublePartialResult);  	
		finalSum += (intPartialResult + doublePartialResult); 
		intPartialResult = doublePartialResult = 0;
	}

	while(tempPipe->Remove(&nextRecord))
	{
		if((comp.Compare(&currentRecord, &nextRecord, groupAtts)) != 0) // Records are not equal
		{ 		
			char *sumArray=new char[sizeof(double)*20]; //////////////////Adjust
			sprintf(sumArray,"%f|",finalSum);

			tempRecord.ComposeRecord(&sumSchema, sumArray); // Compose new record with attribute Sum.
			newRecord.MergeRecords(&tempRecord, &currentRecord, 1, numOfAttsInOrderMaker, attsInOutput, numOfAttsInOutput, 1); // Merge the new Sum record with the original.
			// Record Class Function: MergeRecords (Record *left, Record *right, int numAttsLeft, int numAttsRight, int *attsToKeep, int numAttsToKeep, int startOfRight)
			outPipe->Insert(&newRecord);
			currentRecord.Copy(&nextRecord); // Save the next record as the current record.
			finalSum = 0;
		
		}

		computeMe->Apply(nextRecord, intPartialResult, doublePartialResult);  	
		finalSum += (intPartialResult + doublePartialResult); 
		intPartialResult = doublePartialResult = 0;
	}

	char *sumArray=new char[sizeof(double)*20]; //////////////////Adjust
	sprintf(sumArray,"%f|",finalSum);

	tempRecord.ComposeRecord(&sumSchema, sumArray); // Compose new record.
	newRecord.MergeRecords(&tempRecord, &currentRecord, 1, numOfAttsInOrderMaker, attsInOutput, numOfAttsInOutput, 1); // Merge the records. 
	
	outPipe->Insert(&newRecord);
	outPipe->ShutDown();
}

void GroupBy::WaitUntilDone () 
{
	pthread_join (thread, NULL);
}


void GroupBy::Use_n_Pages (int n) 
{
	runlen = n;
}


/* WriteOut Functions */

WriteOut::WriteOut()
{
}

void * wo_routine (void *ob_param)
{
	WriteOut *wo_ob = (WriteOut*) ob_param;
	wo_ob->Worker();
	pthread_exit(NULL);	
}

void WriteOut::Run (Pipe &inPipe, FILE *outFile, Schema &mySchema) 
{

		this->inPipe=&inPipe;
		this->outFile=outFile;
		this->mySchema=&mySchema;

		pthread_create(&thread,NULL,(wo_routine),(void*)this);

}

void WriteOut:: Worker() 
{
	Record tempRecord;
	
	while(inPipe->Remove(&tempRecord))
	{
		tempRecord.writeToFile(mySchema,outFile);
	}
}

void WriteOut::WaitUntilDone () 
{

	pthread_join (thread, NULL);
	fclose(outFile);
}

void WriteOut::Use_n_Pages (int n) 
{
	runlen=n;
}




void *ProjectThread(void *projectObject)
{
	Project *po = (Project *)projectObject;
	po->RunProject();
	pthread_exit(NULL);
}


void Project::Run (Pipe &inPipe, Pipe &outPipe, int *keepMe, int numAttsInput, int numAttsOutput) 
{

		this->inputPipe=&inPipe;
		this->outputPipe=&outPipe;
		this->keepMe=keepMe;
		this->numAttsInput=numAttsInput;
		this->numAttsOutput=numAttsOutput;
		
		int pthread_temp_var = pthread_create(&worker_thread,NULL,ProjectThread,(void *) this); //creates a worker thread
		//start_routine. this object must be passed by reference cast as a pointer of type void
     
		if(pthread_temp_var)
		{
			cout<<"Error in creating a thread \n";
			exit(-1);
		}

}

void Project::RunProject()
{
	Record *tempRec = NULL;
	tempRec = new Record();
	while (inputPipe->Remove (tempRec) ) 
	{
		tempRec->Project(keepMe,numAttsOutput,numAttsInput);	//		
		outputPipe->Insert(tempRec);
		tempRec = new Record();
		//cout<<"in project"<<endl;
	}
	outputPipe->ShutDown();
}

void Project::WaitUntilDone () {
//wait for the thread to finish
     pthread_join(worker_thread, NULL);
	 
}

void Project::Use_n_Pages (int n) {
	runlen=n;
}


void *DuplicateRemovalThread(void *duplicateRemovalObject)
{
	DuplicateRemoval *dro = (DuplicateRemoval *)duplicateRemovalObject;
	dro->RunDuplicateRemoval();
	pthread_exit(NULL);
}

void DuplicateRemoval::Run (Pipe &inPipe, Pipe &outPipe, Schema &mySchema)
{
		this->inputPipe = &inPipe;
		this->outputPipe = &outPipe;
		this->mySchema = &mySchema;
		
		int pthread_temp_var = pthread_create(&worker_thread,NULL,DuplicateRemovalThread,(void *) this); //creates a worker thread
		//start_routine. this object must be passed by reference cast as a pointer of type void
     
		if(pthread_temp_var)
		{
			cout<<"Error in creating a thread \n";
			exit(-1);
		}
}

void DuplicateRemoval::RunDuplicateRemoval()
{
		myOrderMaker=new OrderMaker(mySchema);
		myOrderMaker->Print();

		Pipe *outBigQ;
		outBigQ=new Pipe(100);
		bigQ=new BigQ(*inputPipe,*outBigQ,*myOrderMaker,runlen);
		Record rec1,rec2;
		//if there are no records in the inputpipe or in the bigQ output pipe - we just have to shutdown the outpipe
		if( !(outBigQ->Remove(&rec1) ) )
		{	outputPipe->ShutDown();
			return;
		}
		
		ComparisonEngine comparisonEngine;
		//otherwise remove records from outBigQ pipe and compare each record with each other record
		//we have already got one record from last remove call
		
		//now since we have used BigQ class which involves vectors and priority queues so the records are in sorted order in outBigQ pipe 
		//so we just need to check two adjacent records if they are similar we skip until we get an unique record
		while( outBigQ->Remove(&rec2) )
		{
			
			if( (comparisonEngine.Compare(&rec1,&rec2,myOrderMaker)) != 0 ) //if there are not equal
			{
				outputPipe->Insert(&rec1);
				rec1.Consume(&rec2);
						
			}
		}//end of while loop
		outputPipe->Insert(&rec1);
		outputPipe->ShutDown();
}

void DuplicateRemoval::WaitUntilDone () {
//wait for the thread to finish
     pthread_join(worker_thread, NULL);
	 
}

void DuplicateRemoval::Use_n_Pages (int n) {
	runlen=n;
}


//JOIN

void *JoinThread(void *joinObject)
{
	Join *jo = (Join *)joinObject;
	jo->RunJoin();
	pthread_exit(NULL);
}


void Join::Run (Pipe &inPipeL, Pipe &inPipeR, Pipe &outPipe, CNF &selOp, Record &literal) 
{

		this->leftInputPipe=&inPipeL;
		this->rightInputPipe=&inPipeR;
		this->outputPipe=&outPipe;
		this->selOp=&selOp;
		this->literal=&literal;
		
		int pthread_temp_var = pthread_create(&worker_thread,NULL,JoinThread,(void *) this); //creates a worker thread
		//start_routine. this object must be passed by reference cast as a pointer of type void
     
		if(pthread_temp_var)
		{
			cout<<"Error in creating a thread \n";
			exit(-1);
		}

}

// Create ordermaker for left and right input pipes using getsortorders
    // If OrderMaker has been created Use BigQ to sort both pipes
    // Merge the two pipes using merge function
    // If Ordermaker has not been created (not an equality check then use block nested loop join
    

void Join::RunJoin()
{
	if( (selOp->GetSortOrders(leftOrder,rightOrder) ) == 0) //if 0 then block nested loop Join else sort-merge Join
			blockNestedLoopJoin();
	else
		sortMergeJoin();
}

void Join::sortMergeJoin()
{

	leftOutBigQ = new Pipe(100);
	rightOutBigQ = new Pipe(100);
	
	//sort the records in both the pipes
	BigQ leftBigQ(*leftInputPipe,*leftOutBigQ,leftOrder,runlen);
	BigQ rightBigQ(*rightInputPipe,*rightOutBigQ,rightOrder,runlen);


		ComparisonEngine comp;
		Record leftCurrentRecord, rightCurrentRecord;
		Record leftNextRecord, rightNextRecord;
		
		Record *rec;
		vector<Record*> leftVector;
		vector<Record*> rightVector;
		
		int leftPipeExhausted = 0;
		int rightPipeExhausted = 0;
		
		//fill in first records in current record variables
		leftOutBigQ->Remove(&leftCurrentRecord);
		rightOutBigQ->Remove(&rightCurrentRecord);

		
		//get ordermaker/cnf attributes for both left and right pipes
		int numAttsLeft = leftCurrentRecord.retNumOfAtts();
		int numAttsRight = rightCurrentRecord.retNumOfAtts();

		int *attsToKeep = new int[numAttsLeft + numAttsRight];
		int index=0;
		for(int i=0;i<(numAttsLeft+numAttsRight);i++)
		{
			if(i==(numAttsLeft))
				index=0;
			attsToKeep[i]=index;
			index++;
		}

		int count = 0;
		int rightFlushed = 1,leftFlushed = 1;
		int result;
		int whileExecutionCount = 0;

		while(true)
		{
			whileExecutionCount++;
			//fill the left vector until first non-matching records
			if(leftFlushed)
			{
				leftFlushed = 0;
				while(true)
				{
					rec = new Record;
					rec->Consume(&leftCurrentRecord);
					leftVector.push_back(rec);

					if(leftOutBigQ->Remove(&leftNextRecord)) //fetch next records from left vector
					{
						//compare next record with the current record, If both are same then current=next
						if(comp.Compare(rec,&leftOrder,&leftNextRecord,&leftOrder) == 0)
							leftCurrentRecord.Consume(&leftNextRecord);
						else
							break;						
					}
					else
					{ //if there are no new records to be removed from leftBigQ then it means the pipe is exhausted
						leftPipeExhausted = 1;
						break;
					}
				}
			}
			
			//fill the right vector untill first non-matching records
			if(rightFlushed)
			{
				rightFlushed = 0;
				while(true)
				{
					rec = new Record;
					rec->Consume(&rightCurrentRecord);

					rightVector.push_back(rec);
					if(rightOutBigQ->Remove(&rightNextRecord)) //fetch next records from right vector
					{
						//rightNextRecord.Print(param->rschema);
						//compare next record with the current record, If both are same then current=next
						if(comp.Compare(rec,&rightOrder,&rightNextRecord,&rightOrder) ==0)
							rightCurrentRecord.Consume(&rightNextRecord);
						else
							break;
					}
					else
					{ //if there are no new records to be removed from rightBigQ then it means the pipe is exhausted
						rightPipeExhausted = 1;
						break;
					}
				}
			}
			
			result = comp.Compare(leftVector[0],&leftOrder,rightVector[0],&rightOrder); //compare the first record from both the vectors
			Record *mergeRecord;
			
			//only when the records match then we merge them and put them into the output pipe
			if(result == 0)
			{
			
				// Step 1:now compare each and every record in left vector to each and every record in right vector
				//	      merge them and insert into outputPipe
				// Step 2:empty out both the record vectors once all records are done
				// Step 3:insert fresh records into the both the vectors
				
				rightFlushed = 1;
				leftFlushed = 1;
				
				//do cartesian join of both the vectors.
				for(int i = 0; i < leftVector.size();i++)
				{

					for(int j = 0; j < rightVector.size(); j++)
					{
						mergeRecord = new Record;
						mergeRecord->MergeRecords(leftVector[i],rightVector[j], numAttsLeft, numAttsRight, attsToKeep, (numAttsLeft+numAttsRight), numAttsLeft);
						outputPipe->Insert(mergeRecord);
						count++;
					}
				}
				
				//clear out entries in both the vectors
				for(int i =0; i < rightVector.size(); i++)
				{
					delete rightVector[i];
				}
				for(int i =0; i < leftVector.size(); i++)
				{
					delete leftVector[i];
				}
				leftVector.clear();
				rightVector.clear();
			}
			else if(result > 0) 	//If left>right then clear out right vector
			{
				rightFlushed = 1;
				for(int i =0; i < rightVector.size(); i++)
				{
					delete rightVector[i];
				}
				rightVector.clear();
			}
			else //If left<right then clear out left vector
			{
				leftFlushed = 1;
				//cout<<"Flushing Right"<<endl;
				for(int i =0; i < leftVector.size(); i++)
				{
					delete leftVector[i];
				}
				leftVector.clear();
			}
			
			if(rightPipeExhausted) //If right pipe exhausted then clear out left vector
			{
				for(int i =0; i < leftVector.size(); i++)
				{
					delete leftVector[i];
				}

				leftVector.clear();
				break;
			}
			else //otherwise fetch another record
			{
				if(rightFlushed)
					rightCurrentRecord.Consume(&rightNextRecord);
			}

			if(leftPipeExhausted) //If left pipe exhausted then clear out right vector
			{
				for(int i =0; i < rightVector.size(); i++)
				{
					delete rightVector[i];
				}

				rightVector.clear();
				break;
			}
			else //otherwise fetch another record
			{
				if(leftFlushed)
					leftCurrentRecord.Consume(&leftNextRecord);
			}

		}
		cout<<"Records Inserted : "<<count<<endl;
		outputPipe->ShutDown();
	
	
}

void Join::blockNestedLoopJoin()
{
		//Block Nested Loop Join
		// Source wikipedia:
		//The block nested loop join algorithm improves on the simple nested loop join by only scanning  once for every group of  tuples. 
		//For example, one variant of the block nested loop join reads an entire page of  tuples into memory and loads them into a hash table. 
		//It then scans , and probes the hash table to find  tuples that match any of the tuples in the current page of . 
		//This reduces the number of scans of  that are necessary.

		
		/*int numAttsLeft=0,numAttsRight=0;
		int *attsToKeep;
		int numAttsToKeep=0,startOfRight=0,i;
   
		//get the numAtts for both left input Pipe and right input Pipe using the Schema
		numAttsLeft = (this->jn_mySchemaL)->GetNumAtts();
		numAttsRight = (this->jn_mySchemaR)->GetNumAtts();
		int size = numAttsLeft+numAttsRight;
		attsToKeep = (int *) malloc(size*sizeof(int));
		for(i =0;i< numAttsLeft;i++)
		{
		attsToKeep[i]=i;
		numAttsToKeep++;
		}
		startOfRight = i;
		for(int k=0,j=numAttsLeft;k<numAttsRight;k++,j++)
		{
		attsToKeep[j]=k;
		numAttsToKeep++;
		}
*/



		int numAttsLeft=0,numAttsRight=0;
		int *attsToKeep;
		int numAttsToKeep=0,startOfRight=0,i;
	
		Record *mergeRecord;		

		DBFile dbfile;
		Record leftRecord,rightRecord;
		Page page;
		int flagtoDetermineEndofAddRecord = 0;
		vector<Record *> recordVector;
		vector<Record*>::iterator itr;
		Record *tmpRecord;
		ComparisonEngine compEng;
		int resultofComparison = 0;
		
		//We first insert the records of right pipe into the temp dbfile
		dbfile.Create ("dbfile.bin", heap, NULL);   
		while(rightInputPipe->Remove(&rightRecord))
		{	
			dbfile.Add(rightRecord);	
		}
		dbfile.Close();
		//Now first load the records of left pipe into the page in memory and for each record in page scan through the dbfile 
		//to obtain a matching record.if record matches than merge them else continue
		dbfile.Open ("dbfile.bin");
		int counter=0;
		while(true)
		{
			//insert the records into the recordVector
			if(leftInputPipe->Remove(&leftRecord)&&(counter<5000))
			{
				recordVector.push_back(&leftRecord);
				counter++;
			}
			
			else
			{	
				//Case1
				//if the counter becomes equal to 3000 than compare each record in dbfile with every record in record vector
				numAttsLeft = leftRecord.retNumOfAtts();
				numAttsRight = rightRecord.retNumOfAtts();
				attsToKeep = new int[numAttsLeft + numAttsRight];

				for(int i = 0; i<numAttsLeft; i++)
					attsToKeep[i] = i;
				for(int i = 0; i<numAttsRight; i++)
					attsToKeep[numAttsLeft+i] = i;

				


				if(counter==5000)
				{
					counter=0;
					dbfile.MoveFirst();
					while(dbfile.GetNext(rightRecord)==1)
					{
						for(itr = recordVector.begin();itr!= recordVector.end();itr++)
						{
							resultofComparison = compEng.Compare(*itr,&rightRecord,literal,	selOp);
							if(resultofComparison==1)
							{
								mergeRecord = new Record();
								mergeRecord->MergeRecords(*itr,&rightRecord,numAttsLeft,numAttsRight,attsToKeep,(numAttsLeft+numAttsRight), numAttsLeft);
								outputPipe->Insert(	mergeRecord);
							}
						}
					}
				recordVector.clear();		
				recordVector.push_back(&leftRecord);
				counter++;
				}

				//Case2
				//In this case the counter was less than 5000 but the pipe becomes empty
				else
				{
					dbfile.MoveFirst();
					while(dbfile.GetNext(rightRecord)==1)
					{
						for(itr = recordVector.begin();itr!= recordVector.end();itr++)
						{
							resultofComparison = compEng.Compare(*itr,&rightRecord,literal,	selOp);
							if(resultofComparison==1)
							{
								mergeRecord = new Record();
								mergeRecord->MergeRecords(*itr,&rightRecord,numAttsLeft,numAttsRight,attsToKeep,(numAttsLeft+numAttsRight), numAttsLeft);
								outputPipe->Insert(mergeRecord);
							}
						}
					}
				recordVector.clear();
				remove("dbfile.bin");
				remove("dbfile.bin.meta");
				dbfile.Close();
				break;
				}
			}
		}
		
	
	outputPipe->ShutDown();


/*
	Page *page = new Page;
	Record temp;
	Record *rec;
	off_t offset = 0;
	off_t limit = 0;
	char *tempFileName = new char[13];
	int index = 10;
	strcpy(tempFileName,"IntermFile");
	tempFileName[index++] = ch++;
	tempFileName[index] = '\0';
	cout<<"File Created with Name : "<<tempFileName<<endl;
	File file;
	file.Open(0,tempFileName);

	while(param->leftPipe->Remove(&temp))
	{
		rec = new Record;
		rec->Consume(&temp);
		if(!page->Append(rec))
		{
		file.AddPage(page,offset++);
		page->EmptyItOut();
		page->Append(rec);
		}
	}
	file.AddPage(page,offset);
	page->EmptyItOut();
	limit = offset;
	file.Close();
	Record leftRec;
	Record rightRec;
	int numAttsLeft;
	int numAttsRight;
	int *attsToKeep;
	int attribSetFlag = 0;
	ComparisonEngine ce;
	Record *mergeRecord;
	while(param->rightPipe->Remove(&rightRec))
	{
		file.Open(1,tempFileName);
		for(int i = 0; i <= limit; i++)
		{
			file.GetPage(page,i);
			while(page->GetFirst(&leftRec))
			{
				if(attribSetFlag == 0)
				{
					numAttsLeft = leftRec.getAttNum();
					numAttsRight = rightRec.getAttNum();
					attsToKeep = new int[numAttsLeft + numAttsRight];
					for(int i = 0; i < numAttsLeft; i++)
					{
						attsToKeep[i] = i;
					}
					for(int i = 0; i < numAttsRight; i++)
					{
						attsToKeep[numAttsLeft + i] = i;
					}
					attribSetFlag = 1;
				}
				if(ce.Compare(&leftRec,&rightRec,param->litRecord,param->cnfExpression) == 0)
				{
					mergeRecord = new Record;
					mergeRecord->MergeRecords(&leftRec,&rightRec,numAttsLeft,numAttsRight,attsToKeep,(numAttsLeft+numAttsRight),numAttsLeft);
					param->outputPipe->Insert(mergeRecord);
					count++;
				}
			}
			//Not Needed but to be on safer Side.
			page->EmptyItOut();
		}
		file.Close();
	}
	cout<<"Records Insered : "<<count;
*/
}

void Join::WaitUntilDone () {
//wait for the thread to finish
     pthread_join(worker_thread, NULL);
	 
}

void Join::Use_n_Pages (int n) {
	runlen=n;
}

