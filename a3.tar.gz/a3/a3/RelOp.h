#ifndef REL_OP_H
#define REL_OP_H

#include "Pipe.h"
#include "DBFile.h"
#include "Record.h"
#include "Function.h"
#include "Schema.h"
#include "BigQ.h"
#include "Comparison.h"
#include "ComparisonEngine.h"

class RelationalOp 
{
	public:

	// blocks the caller until the particular relational operator 
	// has run to completion
	virtual void WaitUntilDone () = 0;

	// tell us how much internal memory the operation can use
	virtual void Use_n_Pages (int n) = 0;
};

class SelectFile : public RelationalOp { 

	private:
	
	pthread_t thread;

	// Record *buffer;

	DBFile *inFile;
	Pipe *outPipe;
	CNF *selOp;
	Record *literal;

	int runlen;

	public:

	SelectFile();
	void Run (DBFile &inFile, Pipe &outPipe, CNF &selOp, Record &literal);
	void WaitUntilDone ();
	void Use_n_Pages (int n);
	void Worker(void);
	//void * sf_routine(void *ob_param);

};

class SelectPipe : public RelationalOp {

	private:
	
	pthread_t thread;

	Pipe *inPipe;
	Pipe *outPipe;
	CNF *selOp;
	Record *literal;

	int runlen;

	public:

	SelectPipe();
	void Run (Pipe &inPipe, Pipe &outPipe, CNF &selOp, Record &literal);
	void WaitUntilDone ();
	void Use_n_Pages (int n);
	void Worker(void);
	//void sp_routine(void *ob_param);

};

class Project : public RelationalOp { 

		private:
		Pipe *inputPipe;
		Pipe *outputPipe;
		int *keepMe;
		int numAttsInput;
		int numAttsOutput;
		int runlen;
		pthread_t worker_thread;

	public:
	void Run (Pipe &inPipe, Pipe &outPipe, int *keepMe, int numAttsInput, int numAttsOutput) ;
	void WaitUntilDone () ;
	void Use_n_Pages (int n) ;
	void RunProject();
};
class Join : public RelationalOp { 

	private:
		Pipe *leftInputPipe;
		Pipe *rightInputPipe;
		Pipe *outputPipe;
		CNF *selOp;
		Record  *literal;

		int runlen;

		pthread_t worker_thread;

		Pipe *leftOutBigQ;
		Pipe *rightOutBigQ;
	
		BigQ *leftBigQ;
		BigQ *rightBigQ;
		OrderMaker leftOrder,rightOrder;

		
	public:
	void Run (Pipe &inPipeL, Pipe &inPipeR, Pipe &outPipe, CNF &selOp, Record &literal);
	void WaitUntilDone();
	void Use_n_Pages (int n);
	void RunJoin();
	void sortMergeJoin();
	void blockNestedLoopJoin();
};
class DuplicateRemoval : public RelationalOp {
	
	private:
		Pipe *inputPipe;
		Pipe *outputPipe;
		Schema *mySchema;
		int runlen;
		pthread_t worker_thread;
		BigQ *bigQ;
		OrderMaker *myOrderMaker;
		
	public:
	void Run (Pipe &inPipe, Pipe &outPipe, Schema &mySchema) ;
	void WaitUntilDone () ;
	void Use_n_Pages (int n); 
	void RunDuplicateRemoval();
};


class Sum : public RelationalOp {

	private: 
	
	pthread_t thread;

	Pipe *inPipe;
	Pipe *outPipe;
	Function *computeMe;

	int runlen;

	public:
	
	Sum();
	void Run (Pipe &inPipe, Pipe &outPipe, Function &computeMe);
	void WaitUntilDone ();
	void Use_n_Pages (int n);
	void Worker(void);
	//void sum_routine(void *ob_param);
};


class GroupBy : public RelationalOp {
	
	pthread_t thread;

	Pipe *inPipe;
	Pipe *outPipe;
	OrderMaker *groupAtts;
	Function *computeMe;
	BigQ *bigQ;
	Pipe *tempPipe;
	int runlen;
	
	public:

	GroupBy();
	void Run (Pipe &inPipe, Pipe &outPipe, OrderMaker &groupAtts, Function &computeMe);
	void WaitUntilDone ();
	void Use_n_Pages (int n);
	void Worker(void);
	//void * gb_routine(void *ob_param);
};


class WriteOut : public RelationalOp {

	pthread_t thread;

	Pipe *inPipe;
	FILE *outFile;
	Schema *mySchema;
	int runlen;

	public:

	WriteOut();
	void Run (Pipe &inPipe, FILE *outFile, Schema &mySchema);
	void WaitUntilDone ();
	void Use_n_Pages (int n);
	void Worker(void);
	//void wo_routine(void *ob_param);
};
#endif

