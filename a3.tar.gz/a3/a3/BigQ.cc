#include "BigQ.h"


struct queueElements
{
    Record record;
    int run_no;
};


class myComparePQ
{
    private:
        OrderMaker* sortOrder;
    public:
        myComparePQ(OrderMaker *sortorder)
        {
            sortOrder = sortorder;
        }
        int operator()(queueElements* prev,queueElements* next) //overrides the default operator <
        {
            ComparisonEngine comparisonEngine;

        if( (comparisonEngine.Compare(&(prev->record),&(next->record),sortOrder)) <= 0 ) //Comparison engine returns a -1,0,1 if left is less than,equal to or greater than right resp.
            return 0;
        else
            return 1;
           
    }//end of operator function
};



class myCompare
{
    private:
        OrderMaker* sortOrder;

    public:
        myCompare(OrderMaker *sortorder)
        {
            sortOrder = sortorder;
        }
        int operator()(Record* prev,Record* next) //overrides the default operator <
        {
            ComparisonEngine comparisonEngine;
           
        if( (comparisonEngine.Compare(prev,next,sortOrder)) < 0 ) //Comparison engine returns a -1,0,1 if left is less than,equal to or greater than right resp.
                return 1;
        else
                return 0;
           
    }//end of operator function
};

/*The start function to start the worker thread and our implementation*/
void *start_routine(void *bigQObject)
{
    BigQ *bq = (BigQ *)bigQObject;
    bq->phase1(); //phase1
    bq->phase2(); //phase2
    pthread_exit(NULL);
}


/*Constructor*/
BigQ :: BigQ (Pipe &in, Pipe &out, OrderMaker &sortorder, int runlen)
{
    inPipe = &in;
    outPipe = &out;
    sortOrder = &sortorder;
    runLength = runlen;
    totalPages = 0;
    numOfRuns = 0;
       
    int pthread_temp_var = pthread_create(&worker_thread,NULL,start_routine,(void *) this); //creates a worker thread
     //start_routine. this object must be passed by reference cast as a pointer of type void
     
    if(pthread_temp_var)
    {
        cout<<"Error in creating a thread \n";
        exit(-1);
    }
       
}


/*Reads data from input pipe and sorts them into runlen pages*/
   
void BigQ :: phase1()
{
    vector<Record*> recordVector; //to store the runs of records before writing to disk
    Record *record = new Record;
    Record *copyrecord;
    Page tempPage;
        int pageNum = 0; //to get the page count for matching with run length
        myFile.Open(0,"mytemp.bin"); //opening up the binary file to store all the records after they have been sorted
    myCompare obj(sortOrder);
           
        while(inPipe->Remove(record)) //start reading records from the input pipe. Remove accepts pointer to a record
       {
        copyrecord = new Record;
            copyrecord->Copy(record);
   
        if( !tempPage.Append(record) )  //add record to the end of the current page
           
        {
            //if page becomes full then start a new page
           
            pageNum = pageNum+1; //new page
           
            //if we have reached the run length of pages then sort the vector, write to file and start a new run
            if(pageNum == runLength)
            {
                sort (recordVector.begin(), recordVector.end(), obj); //sort vector (temp data structure)
                write(recordVector);
                recordVector.clear(); //flush out vector for new run of pages of records
                pageNum = 0; //reset the pageNum counter
                numOfRuns = numOfRuns + 1;
            }

            tempPage.EmptyItOut(); //flush the old page of previous loop run
            tempPage.Append(record); //append to new page

        }
        recordVector.push_back(copyrecord); //add to temp data structure - records vector
    }

    //all records are read from pipe but the current run of vector may still be unsorted i.e currently vector may have half run of pages

        //for the remaining records in the vector perform the above operations again
    if(recordVector.size() != 0)
    {
        sort (recordVector.begin(), recordVector.end(), obj); //sort vector (temp data structure)
        write(recordVector);
        recordVector.clear();
        numOfRuns = numOfRuns + 1;
    }
   
    myFile.Close();
}

/*Writes to binary file*/
void BigQ :: write (vector<Record*> recordVector)
{

    Page tpage;
    vector<Record*>::iterator itr;
    int pageNum = 1;
    pagesIndexOfEachRun.push_back(totalPages);

    for(itr = recordVector.begin();itr != recordVector.end(); ++itr)
    {
        if( !tpage.Append(*itr) )
        {
            myFile.AddPage(&tpage,(off_t) totalPages++);
            tpage.EmptyItOut();
            tpage.Append(*itr);
            pageNum++; 
        }

    }


        //write the last page in the memory because recordVector.end() does not get last record
    myFile.AddPage(&tpage,(off_t)totalPages++);
     
    pagesInEachRun.push_back(pageNum++);
     tpage.EmptyItOut();

}


void BigQ :: phase2()
{

    myFile.Open(1,"mytemp.bin");
    struct queueElements *qe;   
    Page pageArray[numOfRuns]; //for storing the head page(afterwards subsequent pages) of each run
   
    priority_queue< queueElements *, vector<queueElements *>, myComparePQ > pq (sortOrder);
       
    for(int i=0; i<numOfRuns; i++)
    {
        qe = new queueElements;
        pageArray[i].EmptyItOut();
       
        myFile.GetPage(&pageArray[i],(off_t)pagesIndexOfEachRun[i]);
        pagesIndexOfEachRun[i]++; //increment the index of next page to be fetched for that run
        pagesInEachRun[i]--; //count of pages currently in the run gets decremented
       
            if(pageArray[i].GetFirst(&(qe->record)) )
            {
                qe->run_no = i;
                pq.push(qe);
            }

        }
   
        while( !pq.empty() )
        {
           
            qe = pq.top();
            pq.pop();
            int run_Num = qe->run_no;
           
            outPipe->Insert(&(qe->record));
                       
            delete qe;
            qe = new queueElements;

            if(pageArray[run_Num].GetFirst(&(qe->record)) ) //check if the page still has records
            {
                qe->run_no = run_Num;
                pq.push(qe);
            }

            else
            {
                if(pagesInEachRun[run_Num]!=0) //also check whether the count of number of pages for each run hasnt gone to 0
                {
                    int runNoOfPage = pagesIndexOfEachRun[run_Num];
                    pagesIndexOfEachRun[run_Num]++; //increment the index of next page to be fetched for that run
                    pageArray[run_Num].EmptyItOut(); //empty the page for the new page
                   
                    myFile.GetPage(&pageArray[run_Num],(off_t)runNoOfPage); //get newxt page for the same run from the file
                    pagesInEachRun[run_Num]--; //count of pages gets decremented   
                    pageArray[run_Num].GetFirst(&(qe->record)); //start fetching records from the newly extracted page
                    qe->run_no = run_Num;
                    pq.push(qe);
                   
                }
               
            }
                               
        }//end of while loop
       
        myFile.Close();
        outPipe->ShutDown (); //shut down the outpipe pipe
}

BigQ::~BigQ () {
}










